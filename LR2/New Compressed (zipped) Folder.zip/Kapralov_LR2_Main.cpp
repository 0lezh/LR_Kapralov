#include "Kapralov_LR2_Phone.h"
#include <iostream>
#include <vector>
#include <map>
#include <functional>

// Объявление внешних переменных и функций
extern std::vector<Phone> phoneDatabase;
extern void loadFromFile();
extern void addPhone(const Phone&);
extern void displayAllPhones();
extern void displayPhonesWithLocalCallTimeAbove(int);
extern void displayPhonesWithLongDistanceCalls();
extern void displayPhonesSortedByName();

void displayMenu() {
    std::cout << "\nМеню базы данных телефонов:\n";
    std::cout << "1. Загрузить базу данных из файла\n";
    std::cout << "2. Добавить новую запись\n";
    std::cout << "3. Показать все записи\n";
    std::cout << "4. Показать абонентов с временем городских разговоров выше порога\n";
    std::cout << "5. Показать абонентов с междугородними разговорами\n";
    std::cout << "6. Показать абонентов, отсортированных по имени\n";
    std::cout << "7. Выход\n";
    std::cout << "Введите выбор (1-7): ";
}

int main() {
    std::map<int, std::function<void()>> menu = {
        {1, []() { loadFromFile(); std::cout << "База данных загружена.\n"; }},
        {2, []() { addPhone(Phone::inputFromKeyboard()); std::cout << "Абонент добавлен.\n"; }},
        {3, []() { displayAllPhones(); }},
        {4, []() { 
            int threshold = inputTime("Введите порог времени городских разговоров (мин): ");
            displayPhonesWithLocalCallTimeAbove(threshold);
        }},
        {5, []() { displayPhonesWithLongDistanceCalls(); }},
        {6, []() { displayPhonesSortedByName(); }},
        {7, []() { std::cout << "Выход...\n"; exit(0); }}
    };

    while (true) {
        displayMenu();
        std::string choiceStr;
        std::getline(std::cin, choiceStr);
        try {
            int choice = std::stoi(choiceStr);
            if (menu.find(choice) != menu.end()) {
                menu[choice]();
            } else {
                std::cout << "Неверный выбор. Попробуйте снова.\n";
            }
        } catch (...) {
            std::cout << "Неверный ввод. Введите число от 1 до 7.\n";
        }
    }

    return 0;
}