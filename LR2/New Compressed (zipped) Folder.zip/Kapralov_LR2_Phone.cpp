#include "Kapralov_LR2_Phone.h"
#include <iostream>
#include <vector>
#include <fstream>
#include <sstream>
#include <algorithm>

const std::string DATA_FILE = "phones.txt";

// Вектор для хранения базы данных абонентов
std::vector<Phone> phoneDatabase;

bool isValidString(const std::string& str) {
    return !str.empty() && str.find_first_not_of(" \t\n") != std::string::npos;
}

bool isValidPhoneNumber(const std::string& pn) {
    return pn.length() >= 10 && std::all_of(pn.begin(), pn.end(), [](char c) { return std::isdigit(c) || c == '+' || c == '-'; });
}

bool isValidTime(int time) {
    return time >= 0;
}

std::string inputString(const std::string& prompt) {
    std::string input;
    do {
        std::cout << prompt;
        std::getline(std::cin, input);
        if (!isValidString(input)) {
            std::cout << "Ошибка: Ввод не может быть пустым. Попробуйте снова.\n";
        }
    } while (!isValidString(input));
    return input;
}

std::string inputPhoneNumber(const std::string& prompt) {
    std::string input;
    do {
        std::cout << prompt;
        std::getline(std::cin, input);
        if (!isValidPhoneNumber(input)) {
            std::cout << "Ошибка: Неверный номер телефона. Попробуйте снова.\n";
        }
    } while (!isValidPhoneNumber(input));
    return input;
}

int inputTime(const std::string& prompt) {
    std::string input;
    int time;
    do {
        std::cout << prompt;
        std::getline(std::cin, input);
        try {
            time = std::stoi(input);
            if (!isValidTime(time)) {
                std::cout << "Ошибка: Время должно быть неотрицательным. Попробуйте снова.\n";
            }
        } catch (...) {
            std::cout << "Ошибка: Неверное число. Попробуйте снова.\n";
            time = -1;
        }
    } while (!isValidTime(time));
    return time;
}

Phone::Phone() : localCallTime(0), longDistanceCallTime(0) {
}

Phone::~Phone() {
}

void Phone::display() const {
    std::cout << "Фамилия: " << surname << ", Имя: " << name << ", Отчество: " << patronymic
              << ", Адрес: " << address << ", Телефон: " << phoneNumber
              << ", Время городских разговоров: " << localCallTime << " мин"
              << ", Время междугородних разговоров: " << longDistanceCallTime << " мин\n";
}

Phone& Phone::inputFromKeyboard() {
    Phone* phone = new Phone();
    phone->surname = inputString("Введите фамилию: ");
    phone->name = inputString("Введите имя: ");
    phone->patronymic = inputString("Введите отчество: ");
    phone->address = inputString("Введите адрес: ");
    phone->phoneNumber = inputPhoneNumber("Введите номер телефона: ");
    phone->localCallTime = inputTime("Введите время городских разговоров (мин): ");
    phone->longDistanceCallTime = inputTime("Введите время междугородних разговоров (мин): ");
    return *phone;
}

bool Phone::hasLocalCallTimeAbove(int threshold) const {
    return localCallTime > threshold;
}

bool Phone::hasLongDistanceCalls() const {
    return longDistanceCallTime > 0;
}

void loadFromFile() {
    std::ifstream file(DATA_FILE);
    if (!file.is_open()) {
        std::cout << "Предупреждение: Не удалось открыть файл " << DATA_FILE << ". Начинаем с пустой базой данных.\n";
        return;
    }

    phoneDatabase.clear();
    std::string line;
    while (std::getline(file, line)) {

        line.erase(0, line.find_first_not_of(" \t\r\n"));
        line.erase(line.find_last_not_of(" \t\r\n") + 1);
        if (line.empty()) continue;

        std::istringstream iss(line);
        Phone phone;
        std::string surname, name, patronymic, address, phoneNumber, localCallTimeStr, longDistanceCallTimeStr;

        std::getline(iss, surname, ',');
        std::getline(iss, name, ',');
        std::getline(iss, patronymic, ',');
        std::getline(iss, address, ',');
        std::getline(iss, phoneNumber, ',');
        std::getline(iss, localCallTimeStr, ',');
        std::getline(iss, longDistanceCallTimeStr);

        surname.erase(0, surname.find_first_not_of(" \t"));
        surname.erase(surname.find_last_not_of(" \t") + 1);
        name.erase(0, name.find_first_not_of(" \t"));
        name.erase(name.find_last_not_of(" \t") + 1);
        patronymic.erase(0, patronymic.find_first_not_of(" \t"));
        patronymic.erase(patronymic.find_last_not_of(" \t") + 1);
        address.erase(0, address.find_first_not_of(" \t"));
        address.erase(address.find_last_not_of(" \t") + 1);
        phoneNumber.erase(0, phoneNumber.find_first_not_of(" \t"));
        phoneNumber.erase(phoneNumber.find_last_not_of(" \t") + 1);
        localCallTimeStr.erase(0, localCallTimeStr.find_first_not_of(" \t"));
        localCallTimeStr.erase(localCallTimeStr.find_last_not_of(" \t") + 1);
        longDistanceCallTimeStr.erase(0, longDistanceCallTimeStr.find_first_not_of(" \t"));
        longDistanceCallTimeStr.erase(longDistanceCallTimeStr.find_last_not_of(" \t") + 1);

        int localCallTime = 0, longDistanceCallTime = 0;
        try {
            localCallTime = std::stoi(localCallTimeStr);
            longDistanceCallTime = std::stoi(longDistanceCallTimeStr);
        } catch (...) {
            continue;
        }

        if (isValidString(surname) && isValidString(name) && isValidString(patronymic) &&
            isValidString(address) && isValidPhoneNumber(phoneNumber) &&
            isValidTime(localCallTime) && isValidTime(longDistanceCallTime)) {
            phone.setSurname(surname);
            phone.setName(name);
            phone.setPatronymic(patronymic);
            phone.setAddress(address);
            phone.setPhoneNumber(phoneNumber);
            phone.setLocalCallTime(localCallTime);
            phone.setLongDistanceCallTime(longDistanceCallTime);
            phoneDatabase.push_back(phone);
        }
    }
    file.close();
}

void addPhone(const Phone& phone) {
    phoneDatabase.push_back(phone);
}

void displayAllPhones() {
    if (phoneDatabase.empty()) {
        std::cout << "База данных пуста.\n";
        return;
    }
    for (const auto& phone : phoneDatabase) {
        phone.display();
    }
}

void displayPhonesWithLocalCallTimeAbove(int threshold) {
    bool found = false;
    for (const auto& phone : phoneDatabase) {
        if (phone.hasLocalCallTimeAbove(threshold)) {
            phone.display();
            found = true;
        }
    }
    if (!found) {
        std::cout << "Не найдено абонентов с временем городских разговоров выше " << threshold << " минут.\n";
    }
}

void displayPhonesWithLongDistanceCalls() {
    bool found = false;
    for (const auto& phone : phoneDatabase) {
        if (phone.hasLongDistanceCalls()) {
            phone.display();
            found = true;
        }
    }
    if (!found) {
        std::cout << "Не найдено абонентов с междугородними разговорами.\n";
    }
}

void displayPhonesSortedByName() {
    std::vector<Phone> sortedPhones = phoneDatabase;
    std::sort(sortedPhones.begin(), sortedPhones.end(), 
        [](const Phone& a, const Phone& b) {
            return a.getSurname() + a.getName() + a.getPatronymic() < 
                   b.getSurname() + b.getName() + b.getPatronymic();
        });
    
    if (sortedPhones.empty()) {
        std::cout << "База данных пуста.\n";
        return;
    }
    for (const auto& phone : sortedPhones) {
        phone.display();
    }
}