#pragma once
#include <string>
#include <vector>

class Phone {
private:
    std::string surname;         // Фамилия абонента
    std::string name;           // Имя абонента
    std::string patronymic;     // Отчество абонента
    std::string address;        // Адрес абонента
    std::string phoneNumber;    // Номер телефона
    int localCallTime;          // Время городских разговоров (мин)
    int longDistanceCallTime;   // Время междугородних разговоров (мин)

public:
    Phone();

    ~Phone();

    inline std::string getSurname() const { return surname; }
    inline std::string getName() const { return name; }
    inline std::string getPatronymic() const { return patronymic; }
    inline std::string getAddress() const { return address; }
    inline std::string getPhoneNumber() const { return phoneNumber; }
    inline int getLocalCallTime() const { return localCallTime; }
    inline int getLongDistanceCallTime() const { return longDistanceCallTime; }

    inline void setSurname(const std::string& s) { surname = s; }
    inline void setName(const std::string& n) { name = n; }
    inline void setPatronymic(const std::string& p) { patronymic = p; }
    inline void setAddress(const std::string& a) { address = a; }
    inline void setPhoneNumber(const std::string& pn) { phoneNumber = pn; }
    inline void setLocalCallTime(int lct) { localCallTime = lct; }
    inline void setLongDistanceCallTime(int ldct) { longDistanceCallTime = ldct; }

    // Прототипы методов
    void display() const;                     // Отображение данных абонента
    static Phone& inputFromKeyboard();        // Ввод данных с клавиатуры
    bool hasLocalCallTimeAbove(int threshold) const; // Проверка превышения времени городских разговоров
    bool hasLongDistanceCalls() const;       // Проверка наличия междугородних разговоров
};

// Объявления функций для работы с базой данных
void loadFromFile();                              // Загрузка данных из файла
void addPhone(const Phone& phone);                // Добавление абонента в базу данных
void displayAllPhones();                          // Отображение всех абонентов
void displayPhonesWithLocalCallTimeAbove(int threshold); // Отображение абонентов с временем городских разговоров выше порога
void displayPhonesWithLongDistanceCalls();        // Отображение абонентов с междугородними разговорами
void displayPhonesSortedByName();                 // Отображение абонентов, отсортированных по имени
int inputTime(const std::string& prompt);         // Ввод времени с проверкой корректности